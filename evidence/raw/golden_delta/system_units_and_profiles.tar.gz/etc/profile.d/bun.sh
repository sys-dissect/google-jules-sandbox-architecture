export BUN_INSTALL=/usr/local/bun
export PATH="/usr/local/bun/bin:$PATH"
